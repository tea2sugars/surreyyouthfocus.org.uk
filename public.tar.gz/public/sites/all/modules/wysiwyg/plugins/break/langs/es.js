
tinyMCE.addToLang('break', {
  title: 'Insertar marcador de documento recortado',
  desc: 'Generar el punto de separación entre la versión recortada del documento y el resto del contenido'
});

